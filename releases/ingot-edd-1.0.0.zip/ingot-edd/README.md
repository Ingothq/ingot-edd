# Ingot - Easy Digital Downloads
Add-on to add basic Easy Digital Downloads to Ingot, the easiest A/B testing tool for WordPress. For full Ingot EDD support, upgrade to Ingot Premium.

<strong>[Learn More At IngotHQ.com](http://ingothq.com)</strong>

### YOU PROBABLY SHOULDN'T USE THIS REPO
This repo uses Composer for dependency management. If you want to try this plugin, download Ingot, and start a free trial of the add-on.

### Copyright/ License
Copyright 2016 Josh Pollock & Ingot LLC. Licensed under the terms of the GNU GPL v2 or later.
